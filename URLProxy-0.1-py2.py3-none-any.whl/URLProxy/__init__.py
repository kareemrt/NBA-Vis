import json
import random
import time
from requests import Session
session = Session()
def read_credentials():
    '''For use in force_connect(), loads HTML headers, Socks5 proxies, proxy username, password, and credentials'''
    with open('IO/credentials.json', "r") as c:
        data = json.load(c)
        username, password, credentials = data['credentials']
        headers = [header for header in data['headers']]
        proxies = [proxy for proxy in data['proxies']]
    return username, password, credentials, proxies, headers

user, passw, credentials, proxies, headers = read_credentials()

def force_connect(url):
    '''Returns a web request that avoids proxy detection using Socks5 proxies'''
    IP, agent = random.choice(proxies), random.choice(headers)
    proxy = "socks5h://" + credentials + '@' + IP + ":1080"
    url_req = -1
    while url_req == -1:
        try: url_req = session.get(url, proxies={'http':proxy, 'https':proxy}, headers={'User-Agent':agent}, timeout=10)
        except Exception:
            print(f"Connection Error via proxy: {IP}")
            IP, agent = random.choice(proxies), random.choice(headers)
            proxy = "socks5h://" + credentials + '@' + IP + ":1080"
            time.sleep(1)
    print(f'Successful connection via proxy: {IP}')
    return url_req